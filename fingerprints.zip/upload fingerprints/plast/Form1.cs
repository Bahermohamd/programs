﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Globalization;

namespace plast
{
    public partial class Form1 : Form
    {
        DB_con db = new DB_con();
        public Form1()
        {
            InitializeComponent();
        }

        bool user_found(string badge)
        {
            try { db.readData("select userid from userinfo where badgenumber = '" + badge + "'", "").Rows[0][0].ToString(); return true; }
            catch { return false; }
        }

        void getFromAccess(string num)
        {
            int success = 0, fail = 0, added = 0;
            DateTime date = new DateTime();
            string time = "", userid;

            // Connection string for Access database
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Program Files (x86)\ZKTeco\att2000.mdb";
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                // ... perform database operations here ...
                string stmt = "SELECT TOP " + num + " USERINFO.Badgenumber, CHECKINOUT.CHECKTIME, CHECKINOUT.CHECKTYPE " +
                                "FROM USERINFO INNER JOIN CHECKINOUT ON USERINFO.USERID = CHECKINOUT.USERID " +
                                "ORDER BY CHECKINOUT.CHECKTIME DESC;";
                OleDbCommand command = new OleDbCommand(stmt, connection);
                try
                {
                    connection.Open();
                    OleDbDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        date = DateTime.Parse(reader["CHECKTIME"].ToString());
                        time = date.ToString("yyyy-MM-dd HH:mm:ss");


                        try
                        {
                            if (!user_found(reader["BADGENUMBER"].ToString()))
                            {
                                stmt = "insert into USERINFO values('" + reader["BADGENUMBER"] + "',	NULL,	'" + reader["BADGENUMBER"] + "',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	1,	1,	1,	1,	1,	1,	NULL,	NULL,	1,	NULL,	NULL,	NULL,	0,	1,	1,	1,	24,	1,	1,	0, NULL,	0,	1,	1,	0,	0,	0,	NULL,	NULL,	1,	0,	0,	NULL)";
                                db.exceuteData(stmt, "");
                                added += 1;
                            }

                            userid = db.readData("select userid from userinfo where badgenumber = '" + reader["BADGENUMBER"] + "'", "").Rows[0][0].ToString();


                            stmt = ("INSERT INTO [dbo].[CHECKINOUT] ([USERID],[CHECKTIME],[CHECKTYPE],[VERIFYCODE],[SENSORID],[Memoinfo],[WorkCode],[sn],[UserExtFmt],[Exported],[IsManual])" +
                        " VALUES( " + userid + ", '" + time + ".000', '" + reader["CHECKTYPE"] + "', 1, '28', NULL, 0, 'CJRJ205160606', 0, 0, 0)\r\n");
                            if (db.exceuteData(stmt, "")) success += 1;
                            else fail += 1;
                        }
                        catch
                        { }
                    }
                    
                    MessageBox.Show("done\nSucceed: " + success + "\nFalied: " + fail + "\nAdded: " + added);
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void btn_enter_Click(object sender, EventArgs e)
        {
            getFromAccess(txt.Text.ToString());
        }
    }
}
