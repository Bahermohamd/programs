﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZKTeco_Reset_Pass
{
    class clsZKTeco
    {
        
        ZKTeco_DBEntities db = new ZKTeco_DBEntities();

        public List<USERINFO> findBynumber(string badg)
        {
           
                var result = db.USERINFO.Where(s => s.BADGENUMBER == badg).ToList();

                return result;
            
        }


        public void Update(string badg)
        {
            try{
                var result = db.USERINFO.SingleOrDefault(c => c.BADGENUMBER == badg);
                string pass = "	NDYwMjw=";
                result.PASSWORD = pass;
                MessageBox.Show("New Password is: 13579");

                db.SaveChanges();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message);  }
   
        }

       
    }
}
