﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZKTeco_Reset_Pass
{
    public partial class Form1 : Form
    {
        clsZKTeco user = new clsZKTeco();
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_ResetPass_Click(object sender, EventArgs e)
        {
            try
            {
                var result = user.findBynumber(textBox1.Text);
                if (result.Count() >= 1)
                {
                    user.Update(textBox1.Text);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

            
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Copyright © Hossam Refaey" + " - " + DateTime.Now.Year.ToString();
        }
    }
}
