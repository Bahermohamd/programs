﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Globalization;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            test();
        }

        void test()
        {
            char[] delimiters = new char[] { ',' };
            cls_DBcon db = new cls_DBcon();
            using (StreamWriter writer = new StreamWriter(@"C:\Users\baher.mohamed\Desktop\qr.txt"))
            {
                using (StreamReader reader = new StreamReader(@"C:\Users\baher.mohamed\Desktop\final.csv"))
                {
                    string error = "";
                    while (true)
                    {
                        string line = reader.ReadLine();
                        if (line == null)
                        {
                            break;
                        }
                        string[] parts = line.Split(delimiters);
                        string stmt = "select USERID from USERINFO where BADGENUMBER = '" + parts[0] + "'";
                        string id;
                        try
                        {
                             id = db.readData(stmt, "").Rows[0][0].ToString();
                            writer.Write("INSERT INTO [dbo].[CHECKINOUT] ([USERID],[CHECKTIME],[CHECKTYPE],[VERIFYCODE],[SENSORID],[Memoinfo],[WorkCode],[sn],[UserExtFmt],[Exported],[IsManual])" +
                            "VALUES(" + id + ",'" + parts[1] + " " + parts[2] + ".000', '" + parts[3] + "', 1, '28', NULL, 0, 'CJRJ205160606', 0, 0, 0)\r\n");

                        }
                        catch { error += parts[0] + "\n"; };

                        
                    }
                    MessageBox.Show(error);
                    MessageBox.Show("done");
                }
            }
            
        }
    }
}
