﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZKTeco.Controller;

namespace ZKTeco.Views
{
    public partial class frm_attendance : Form
    {
        cls_DBcon con = new cls_DBcon();
        DataTable branch;

        public frm_attendance()
        {
            
            InitializeComponent();
            
        }


        public void load()
        {
            string userid  = con.readData("select USERID from USERINFO where BADGENUMBER = '" + txt_code.Text.ToString() + "'", "").Rows[0][0].ToString();
            dgv_List.DataSource = con.readData("SELECT TOP 30 CHECKTIME, CHECKTYPE, SENSORID from CHECKINOUT where userid = " + userid + "order by CHECKTIME desc", "");
            dgv_List.Columns["CHECKTIME"].Width = 240;

            cmb_Type.DataSource = new Dictionary<int, string>()
            {
                {1, "Finger"},
                { 4, "Card"},
                {15, "Face"}
            }.ToList();
            cmb_Type.ValueMember = "Key";
            cmb_Type.DisplayMember = "Value";
            cmb_Type.SelectedIndex = 0;
        }

        //userinfo check
        //NumericUpDown



        private void btn_check_Click(object sender, EventArgs e)
        {
            string userid = "" , sn = "", time = "", br, type = "";
            string code = txt_code.Text.ToString();



            if (!rdb_in.Checked && !rdb_out.Checked) MessageBox.Show("You Have To Choose In or Out");

            else if (cmb_br.Text == "") MessageBox.Show("You Have To Select a Branch");

            //else if (cmb_hour.Text == "") MessageBox.Show("You Have To enter checkin/out Hour");
            //else if (cmb_min.Text == "") MessageBox.Show("You Have To enter checkin/out Minutes");

            else
            {
 
                br = cmb_br.SelectedValue.ToString();
                userid = con.readData("select USERID from USERINFO where BADGENUMBER = '" + code + "'", "").Rows[0][0].ToString();
                time = DateTime.Now.ToString((dateTimePicker1.Value).ToString("yyyy-MM-dd") +" "+ cmb_hour.SelectedItem + ":"+ cmb_min.SelectedItem + ":"+"ss.000");

                //2023-11-01 09:12:17.000
                //time = DateTime.Now.ToString("yyyy-MM-dd ")
                //  + cmb_hour.Text
                //  + ":" + min + ":"
                //  + DateTime.Now.ToString("ss") + ".000";



                if (rdb_in.Checked)  type = "I";
                else if (rdb_out.Checked)  type = "O";
                else MessageBox.Show("choose in or out");

                int UserExtFmt = 0;

                if(br=="250")
                {
                    UserExtFmt = 1;
                }

                string stmt = "INSERT INTO[dbo].[CHECKINOUT]([USERID],[CHECKTIME],[CHECKTYPE],[VERIFYCODE],[SENSORID],[Memoinfo],[WorkCode],[sn],[UserExtFmt],[Exported],[IsManual])" +
                " VALUES(" + userid + ", '" + time + "', '" + type + "', "+int.Parse(cmb_Type.SelectedValue.ToString())+" , " + br + ", NULL,0, '" + branch.Rows[0][0].ToString() + "',"+ UserExtFmt + ",0,0)";

                if (con.exceuteData(stmt, "")) MessageBox.Show("Added Successfully", "Note", MessageBoxButtons.OK, MessageBoxIcon.Information);

                load();
            }
        }

        private void btn_ext_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cmb_br_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                branch = con.readData("select sn from Machines where  MachineNumber = " + int.Parse(cmb_br.SelectedValue.ToString()), "");
            }
            catch 
            {
                return;
            }
        }

        private void frm_attendance_Load(object sender, EventArgs e)
        {
            try
            {


                txt_code.Text = Properties.Settings.Default.emp_code;
                string stmt = "select MachineNumber,MachineAlias from Machines order by MachineNumber asc";
                branch = con.readData(stmt, "");
                cmb_br.DataSource = branch;
                cmb_br.ValueMember = "MachineNumber";
                cmb_br.DisplayMember = "MachineAlias";
                cmb_br.SelectedIndex = -1;


                for (int i = 0; i < 60; i++)
                {
                    if (i >= 8 && i <= 24)
                    {
                        if (i < 10)
                        {
                            cmb_hour.Items.Add("0" + i);
                        }
                        else
                        {
                            cmb_hour.Items.Add(i);

                        }
                    } 
                    if (i < 10)
                    {
                        cmb_min.Items.Add("0" + i);
                    }
                    else
                    {
                        cmb_min.Items.Add(i);

                    }
                }

                cmb_min.SelectedIndex = 0;
                cmb_hour.SelectedIndex = 0;

                

                load();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
                Application.Exit();
            }
        }

        private void rdb_in_CheckedChanged(object sender, EventArgs e)
        {
            cmb_hour.Text = "09";
        }

        private void rdb_out_CheckedChanged(object sender, EventArgs e)
        {
            cmb_hour.Text = "17";
        }


        private void txt_code_TextChanged(object sender, EventArgs e)
        {
            load();
        }
    }
}
