﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZKTeco.Controller;

namespace ZKTeco.Views
{
    public partial class frm_login : Form
    {
        
        SqlConnection con = new SqlConnection(@"Data Source=10.20.0.25;Initial Catalog=ZKTeco_DB;Integrated Security=False;user id=sa;password=14982752*;");
        SqlCommand cmd = new SqlCommand();

        public frm_login()
        {
            InitializeComponent();
            txt_usr.Text = "baher.mohamed";
            txt_pass.Text = "baher";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string qry = "select * from user_login where UserName = '" + txt_usr.Text + "' and Password = '" + txt_pass.Text + "' ";
            DataTable tbl = new DataTable();
            try
            {
                cmd.Connection = con;
                cmd.CommandText = qry;

                con.Open();

                tbl.Load(cmd.ExecuteReader());

                con.Close();

                if (tbl.Rows.Count > 0)
                {
                    frm_attendance frm = new frm_attendance();

                    Properties.Settings.Default.emp_code = tbl.Rows[0][3].ToString();
                    Properties.Settings.Default.Save();

                    this.Hide();
                    frm.Closed += (s, args) => this.Close();
                    frm.Show();
                }
                else
                {
                    MessageBox.Show("something went wrong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_usr.Select();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void txt_pass_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
