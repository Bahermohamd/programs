﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZKTeco.Controller
{
    class cls_DBcon
    {
        

        // Connection String
        SqlConnection con = new SqlConnection(@"Data Source=10.20.0.10;Initial Catalog=ZKTeco_DB;Integrated Security=False;user id=sa; password=sa;");

        //false;User ID = sa; password='"+Properties.Settings.Default.saPass+"'
        

        SqlCommand cmd = new SqlCommand();

        // Select Data From Database Function
        public DataTable readData(string stmt, string Message)
        {
            DataTable tbl = new DataTable();
            try
            {
                cmd.Connection = con;
                cmd.CommandText = stmt;

                con.Open();

                tbl.Load(cmd.ExecuteReader());

                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

            return tbl;
        
        }

       

        // Insert Update Delete
        public bool exceuteData(string stmt, string Message)
        {
            try
            {

                cmd.Connection = con;
                cmd.CommandText = stmt;

                con.Open();
            
                cmd.ExecuteNonQuery();
                con.Close();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }
    }
}
