﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.IO;

namespace do_ping
{
    class Program
    {
        public static string ExecuteCommand(string command)
        {
            int ExitCode;
            string fin;
            ProcessStartInfo ProcessInfo;
            Process Process;

            ProcessInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
            ProcessInfo.CreateNoWindow = true;
            ProcessInfo.UseShellExecute = false;
            ProcessInfo.RedirectStandardOutput = true;


            Process = Process.Start(ProcessInfo);
            Process.WaitForExit();

            fin = Process.StandardOutput.ReadToEnd();
            
            ExitCode = Process.ExitCode;
            Process.Close();
            
            return fin;
        }

        static void Main(string[] args)
        {
            string ip;
            string[] fin = { "", "", "", ""};
            Ping request = new Ping();
            int done = 0;

            string path = @"C:\Users\abdelrahman.ghobashy\Desktop\out.csv";

            using (StreamWriter writer = new StreamWriter(path))
            {

                for (int i = 3; i < 250; i++)
                {
                    ip = "10.44.125." + Convert.ToString(i);

                    string[] a = { "", "", "", "" };
                    Console.WriteLine("Testing " + i + " Right Now");
                    try
                    {
                        PingReply response = request.Send(ip);
                        if (response.Status == IPStatus.Success)
                        {
                            if (response.Options.Ttl > 65 && response.Options.Ttl < 129)
                            {
                                Console.WriteLine("working on " + ip);
                                fin[0] = ExecuteCommand("wmic /node: " + ip + " computersystem get name");
                                a[0] = fin[0].Split('\n')[1].Replace(Convert.ToChar(13).ToString(), "").Replace(Convert.ToChar(10).ToString(), "");
                                a[0] = "(" + a[0].Substring(0, a[0].Length - 2) + ")";


                                fin[1] = ExecuteCommand("wmic /node: " + ip + " baseboard get product");
                                a[1] = fin[1].Split('\n')[1].Replace(Convert.ToChar(13).ToString(), "").Replace(Convert.ToChar(10).ToString(), "");
                                a[1] = "(" + a[1].Substring(0, a[1].Length - 2) + ")";


                                fin[2] = ExecuteCommand("wmic /node: " + ip + " bios get serialnumber");
                                a[2] = fin[2].Split('\n')[1].Replace(Convert.ToChar(13).ToString(), "").Replace(Convert.ToChar(10).ToString(), "");
                                a[2] = "(" + a[2].Substring(0, a[2].Length - 2) + ")";


                                fin[3] = ExecuteCommand("wmic /node: " + ip + " csproduct get name");
                                a[3] = fin[3].Split('\n')[1].Replace(Convert.ToChar(13).ToString(), "").Replace(Convert.ToChar(10).ToString(), "");
                                a[3] = "(" + a[3].Substring(0, a[3].Length - 2) + ")";



                                writer.Write(ip + ", " + a[0] + ", " + a[1] + ", " + a[2] + ", " + a[3] + "\r\n");

                                done += 1;
                                Console.WriteLine("\t" + done + " Device Done");
                                Console.WriteLine("-------------------------------------");
                            }
                        }
                    }
                    catch { }

                }
            }

            Console.WriteLine("All Done");
            Console.ReadLine();
        }
    }
}
