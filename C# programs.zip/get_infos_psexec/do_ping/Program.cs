﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.IO;

namespace do_ping
{
    class Program
    {
        public static string ExecuteCommand(string command)
        {
            int ExitCode;
            string ret = "";
            ProcessStartInfo ProcessInfo;
            Process Process;

            ProcessInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
            ProcessInfo.CreateNoWindow = true;
            ProcessInfo.UseShellExecute = false;
            ProcessInfo.RedirectStandardOutput = true;
            ProcessInfo.RedirectStandardError = true;

            Process = Process.Start(ProcessInfo);
            Process.WaitForExit();

            ret += Process.StandardOutput.ReadToEnd();
            ret += "\n" + Process.StandardError.ReadToEnd();

            ExitCode = Process.ExitCode;
            Process.Close();

            return ret;
        }

        static void Main2(string[] args)
        {
            string ip;
            string[] fin = { "", "", "", ""};
            Ping request = new Ping();
            int done = 0;

            string path = @"C:\Users\abdelrahman.ghobashy\Desktop\out.csv";

            using (StreamWriter writer = new StreamWriter(path))
            {

                for (int i = 3; i < 250; i++)
                {
                    ip = "10.44.125." + Convert.ToString(i);

                    string[] a = { "", "", "", "" };
                    Console.WriteLine("Testing " + i + " Right Now");
                    try
                    {
                        PingReply response = request.Send(ip);
                        if (response.Status == IPStatus.Success)
                        {
                            if (response.Options.Ttl > 65 && response.Options.Ttl < 129)
                            {
                                Console.WriteLine("working on " + ip);
                                //fin[0] = ExecuteCommand("wmic /node: " + ip + " computersystem get name");
                                a[0] = fin[0].Split('\n')[1].Replace(Convert.ToChar(13).ToString(), "").Replace(Convert.ToChar(10).ToString(), "");
                                a[0] = "(" + a[0].Substring(0, a[0].Length - 2) + ")";


                                //fin[1] = ExecuteCommand("wmic /node: " + ip + " baseboard get product");
                                a[1] = fin[1].Split('\n')[1].Replace(Convert.ToChar(13).ToString(), "").Replace(Convert.ToChar(10).ToString(), "");
                                a[1] = "(" + a[1].Substring(0, a[1].Length - 2) + ")";


                                //fin[2] = ExecuteCommand("wmic /node: " + ip + " bios get serialnumber");
                                a[2] = fin[2].Split('\n')[1].Replace(Convert.ToChar(13).ToString(), "").Replace(Convert.ToChar(10).ToString(), "");
                                a[2] = "(" + a[2].Substring(0, a[2].Length - 2) + ")";


                                //fin[3] = ExecuteCommand("wmic /node: " + ip + " csproduct get name");
                                a[3] = fin[3].Split('\n')[1].Replace(Convert.ToChar(13).ToString(), "").Replace(Convert.ToChar(10).ToString(), "");
                                a[3] = "(" + a[3].Substring(0, a[3].Length - 2) + ")";



                                writer.Write(ip + ", " + a[0] + ", " + a[1] + ", " + a[2] + ", " + a[3] + "\r\n");

                                done += 1;
                                Console.WriteLine("\t" + done + " Device Done");
                                Console.WriteLine("-------------------------------------");
                            }
                        }
                    }
                    catch { }

                }
            }

            Console.WriteLine("All Done");
            Console.ReadLine();
        }


        static string handl()
        {
            return System.IO.File.ReadAllText("text.txt")
                .Replace("SerialNumber", "")
                .Replace("\n", "")
                .Replace("\r", "")
                .Replace("\t", "")
                .Replace("Microsoft (R) Windows Script Host Version 5.812Copyright (C) Microsoft Corporation. All rights reserved.", "");
        }

        static void Main()
        {
            string ip = "";
            string subnet = "";
            int start, end;
            int done = 0;
            Ping request = new Ping();


            Console.WriteLine("subnet:..");
            subnet = Console.ReadLine();

            Console.WriteLine("start from:..");
            start = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("end at:..");
            end = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("YOU HAVE TO WAIT UNTIL PROGRAM DONE!!!!");

            using (StreamWriter writer = new StreamWriter("final.csv"))
            {
                writer.Write("ip, sn, mon_sn, host\r\n");
                for (int i = start; i < end+1; i++)
                {
                    ip = subnet + "." + Convert.ToString(i);

                    string sn, m_sn, host;
                    Console.Write("Testing " + i + " Right Now \t");
                    try
                    {
                        PingReply response = request.Send(ip);
                        if (response.Status == IPStatus.Success)
                        {
                            Console.Write("ttl is  " + response.Options.Ttl + "\t");
                            if (response.Options.Ttl > 65 && response.Options.Ttl < 129)
                            {
                                
                                Console.WriteLine("working on " + ip + "\t");


                                ExecuteCommand(@"psexec \\" + ip + " wmic bios get serialnumber > text.txt 2>> error.txt");
                                sn = handl();
                                Console.WriteLine(sn);

                                ExecuteCommand(@"copy .\get_m_sn.vbs \\" + ip + @"\c$\  2>> error.txt");
                                ExecuteCommand(@"psexec \\" +ip + @" cscript c:\get_m_sn.vbs " + ip + " > text.txt 2>> error.txt");
                                ExecuteCommand(@"rm '\\" + ip + @"\c$\get_m_sn.vbs'");
                                m_sn = handl();
                                Console.WriteLine(m_sn);

                                ExecuteCommand(@"psexec \\" + ip + " hostname > text.txt 2>> error.txt");
                                host = handl();
                                Console.WriteLine(host);



                                writer.Write(ip + ", " + sn +  ", " + m_sn + ", " + host + "\r\n");

                                done += 1;
                                Console.WriteLine("\t" + done + " Device Done");
                                Console.WriteLine("-------------------------------------");
                            }
                            else { Console.Write("\n"); }
                        }
                        else { Console.Write("\n"); }
                    }
                    catch { }

                }
            }

            Console.WriteLine("All Done\npress enter twice to exit");
            Console.ReadLine();
            Console.ReadLine();
        }
    }
   

}
