﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.NetworkInformation;
using System.Threading;
using System.IO;

namespace do_ping
{
    class Program
    {




        static void Main(string[] args)
        {
            var branchs = new List<int> {8, 17, 24, 28, 29, 31, 43, 53, 54};


            var tasks = new List<Task>();
            int cpus = Environment.ProcessorCount;
            int pos = 0;

            Console.WriteLine(DateTime.Now);

            for (int i = 0; i < cpus; i++)
            {     
                pos = (branchs.Count / cpus) * i;
                List<int> local = branchs.GetRange(pos, branchs.Count / cpus);
                if (i == cpus-1) local = branchs.GetRange(pos, (branchs.Count / cpus) + (branchs.Count % cpus));
                tasks.Add(Task.Run(() => pinging(local)));
            }
            //var tasks = branchs.Select(item => Task.Run(() => pinging(item))).ToList();
            Task.WaitAll(tasks.ToArray());


            Console.WriteLine("Done");
            Console.WriteLine(DateTime.Now);

            Console.ReadLine();
        }

        static void pinging(List<int> branch)
        {
            int[] poss = { 11, 12, 13, 14, 69};
            string ip = "";
            Ping request = new Ping();
            foreach (int br in branch)
            {
                foreach (int pos in poss)
                {
                    ip = "10.20." + br + "." + pos;
                    try
                    {
                        PingReply response = request.Send(ip);
                        if (response.Status == IPStatus.Success)
                        {
                            Console.WriteLine("{0} ok", ip);
                            //if (Directory.Exists(@"\\" + ip + @"\c$\OPOS"))
                            //{
                            //    Console.WriteLine("{0} still have opos", ip);
                            //    Directory.Delete(@"\\" + ip + @"\c$\OPOS", true);
                            //    Console.WriteLine("now it's deleted");
                            //}
                            //else Console.WriteLine("{0} dont have opos", ip);

                        }
                    }
                    catch { }
                }
            }
        }
    }
}
