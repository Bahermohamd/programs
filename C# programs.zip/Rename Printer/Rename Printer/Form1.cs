﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Management;

namespace Rename_Printer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void RenamePrinter(string oldName, string newName)
        {
            ManagementObjectSearcher query = new ManagementObjectSearcher(
              "SELECT * FROM Win32_Printer");

            ManagementObjectCollection result = query.Get();

            foreach (ManagementObject printer in result)
            {
                if (printer["name"].ToString() == oldName)
                {
                    printer.InvokeMethod("RenamePrinter",
                                         new object[] { newName });
                    return;
                }
            }
        }

        private void SetDefaultPrinter(string printerName)
        {
            ManagementObjectSearcher query = new ManagementObjectSearcher(
              "SELECT * FROM Win32_Printer");

            ManagementObjectCollection result = query.Get();

            foreach (ManagementObject printer in result)
            {
                if (printer["name"].ToString() == printerName)
                {
                    printer.InvokeMethod("SetDefaultPrinter",
                                         new object[] { printerName });
                    return;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (string printer in PrinterSettings.InstalledPrinters)
            {
                cboPrinters.Items.Add(printer);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text)||cboPrinters.SelectedIndex>=0)
            {
                
              
                    RenamePrinter(cboPrinters.Text, textBox1.Text);
                    SetDefaultPrinter(textBox1.Text);
                    MessageBox.Show("Done");


                            


                        
            }
            else
            {
                MessageBox.Show("Select Printer or Enter Printer Name");
            }



        }

        private void cboPrinters_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = string.Format("SELECT DriverName from Win32_Printer where Name = '" + cboPrinters.Text + "'");

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(query))
            using (ManagementObjectCollection coll = searcher.Get())
            {
                try
                {
                    foreach (ManagementObject printer in coll)
                    {
                        foreach (PropertyData property in printer.Properties)
                        {
                            //Console.WriteLine(string.Format("{0}: {1}", property.Name, property.Value));
                            //MessageBox.Show(property.Value.ToString());
                            string driver = property.Value.ToString();
                            //MessageBox.Show(driver);
                            if (driver == "EPSON TM-T88IV ReceiptE4")
                            {

                                textBox1.Text = "EPSON TM-T88IV Receipt";

                            }
                            else if (driver == "EPSON TM-T20 ReceiptE4")
                            {
                                textBox1.Text = "EPSON TM-T20III Receipt";

                            }
                            else
                            {
                                MessageBox.Show("Can't Change This Printer");
                                cboPrinters.SelectedIndex = -1;
                            }

                        }


                    }
                }
                catch (ManagementException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
