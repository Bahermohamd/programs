﻿using System;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.IO;
using System.Net.NetworkInformation;
using System.Timers;
using System.Runtime.InteropServices;
using Renci.SshNet;

namespace Forti_Ping
{
    public partial class Service1 : ServiceBase
    {
        private static bool eventExecutedVDSL = false; // متغير للتحقق من تنفيذ الحدث مرة واحدة
        private static bool eventExecuted4G = false; // متغير للتحقق من تنفيذ الحدث مرة واحدة
        private static int succ = 0;
        private static int pingout = 0;
        private static string user = "--";
        private static string pass = "--";
        private static string ip = "";
        private static string strLog = "";
        private static string FilePath = @"D:\Forti_Ping\";
        private static string host = "";
        private static int fortipingcount =0;
        private static string filePath;
        private static int PingTime = 0;

        Timer timer = new Timer();

        public class IniFile
        {
            private string filePath;

            [DllImport("kernel32")]
            private static extern long WritePrivateProfileString(string section,
                string key, string val, string filePath);

            [DllImport("kernel32")]
            private static extern int GetPrivateProfileString(string section,
                     string key, string def, StringBuilder retVal,
                int size, string filePath);

            public IniFile(string path)
            {
                filePath = path;
            }

            public void Write(string section, string key, string value)
            {
                WritePrivateProfileString(section, key, value, this.filePath);
            }

            public string Read(string section, string key)
            {
                StringBuilder retVal = new StringBuilder(255);
                GetPrivateProfileString(section, key, "", retVal, 255, this.filePath);
                return retVal.ToString();
            }
        }


        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            // Start the application when the service starts
            StartMyApplication();
        }

        protected override void OnStop()
        {
            // Stop the application when the service stops
            StopMyApplication();
        }

        private void StartMyApplication()
        {
            IniFile iniFile = new IniFile(FilePath+@"Config.ini");
            ip = iniFile.Read("Con", "IP");
            host = iniFile.Read("Con", "Ping");
            filePath = FilePath + "BR"+iniFile.Read("Setting", "BR") + "_Log.txt"; // تحديد المسار للملف
            PingTime = int.Parse(iniFile.Read("Setting", "Time"));

            // التحقق مما إذا كان الملف موجوداً
            if (!File.Exists(filePath))
            {
                FileStream fs = File.Create(filePath);
            }

            timer.Elapsed += new ElapsedEventHandler(PingGoogleEvent);
            timer.Interval = 1000; // بالميلي ثانية (1 ثانية)
            timer.Start();


            // Replace "YourApplication.exe" with the path to your application
            //myProcess = Process.Start(@"D:\FortiPing\FortiPing.exe");
        }

        private void StopMyApplication()
        {
            
            // Stop the process if it's running
            //if (myProcess != null && !myProcess.HasExited)
            //{
            //    myProcess.Kill();
            //    myProcess.Dispose();
            //}
            timer.Stop();

        }

        private static void PingGoogleEvent(object source, ElapsedEventArgs e)
        {
            
            Ping pingSender = new Ping();
            int timeout = 1000; // 1 ثانية

            try
            {
                PingReply reply = pingSender.Send(host, timeout);
                PingReply fortireply = pingSender.Send(ip, timeout);

                if (fortireply.Status == IPStatus.Success)
                {
                    fortipingcount = 0;

                    if (reply.Status == IPStatus.Success)
                    {
                        //Console.WriteLine($"Reply from {host} time={reply.RoundtripTime}ms");
                        succ += 1;
                        pingout = 0;
                        if (eventExecutedVDSL !=true && succ == PingTime) // التحقق من عدم تنفيذ الحدث مرة واحدة
                        {
                            // قم بتنفيذ الحدث المطلوب هنا
                            ExecuteOnceEventOnSuccess();
                            eventExecutedVDSL = true; // قم بتعيين القيمة للتأكيد على تنفيذ الحدث مرة واحدة
                            eventExecuted4G = false;

                        }
                    }
                    else if (reply.Status != IPStatus.Success)
                    {
                        //Console.WriteLine("Request timed out");
                        pingout += 1;
                        if (pingout > 5)
                        {
                            succ = 0;
                            if (eventExecuted4G != true && pingout == PingTime) // التحقق من عدم تنفيذ الحدث مرة واحدة
                            {
                                // قم بتنفيذ الحدث المطلوب هنا
                                ExecuteOnceEventOnnotSuccess();
                                eventExecuted4G = true; // قم بتعيين القيمة للتأكيد على تنفيذ الحدث مرة واحدة
                                eventExecutedVDSL = false;
                            }
                        }
                        
                    }
                }
                else 
                {
                    fortipingcount++;

                    if (fortipingcount == 5)
                    {
                        strLog = File.ReadAllText(filePath);
                        File.WriteAllText(filePath, strLog + "\r\n" +"[-] "+ "Forti Down" +" "+ DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt"));
                        fortipingcount = 0;
                    }
                    




                }
            }
            catch (Exception ex)
            {
                //strLog = File.ReadAllText(FilePath + @"log.txt");
                //File.WriteAllText(FilePath + @"log.txt", strLog + "\r\n"+"================="+"\r\n"+ DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt") + "\r\n" + ex.Message);
                return;
            }

        }

        // الحدث المستدعى لمرة واحدة عند نجاح الرد
        private static void ExecuteOnceEventOnSuccess()
        {
            

            string str = File.ReadAllText(FilePath+@"wan.txt");
            try
            {
                AuthenticationMethod method = new PasswordAuthenticationMethod(user, pass);
                ConnectionInfo connection = new ConnectionInfo(ip, user, method);
                SshClient client = new SshClient(connection);

                if (!client.IsConnected)
                {
                    client.Connect();


                    SshCommand response = client.RunCommand(str);

                    
                    

                    strLog = File.ReadAllText(filePath);
                    File.WriteAllText(filePath, strLog + "\r\n" + "[✓] " + "HO_Backup_Disable" + " (" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt") +")  ==> (Back to WAN)");
                    //txt_response.Text = response.Result;

                }
            }
            catch (Exception ex)
            {
                strLog = File.ReadAllText(filePath);
                File.WriteAllText(filePath, strLog + "\r\n" + "[-] " + ex.Message + " " + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt"));

                return;
            }
            // قم بتنفيذ الإجراء المطلوب هنا
        }
        private static void ExecuteOnceEventOnnotSuccess()
        {
            
            string str = File.ReadAllText(FilePath + @"4G.txt");
            try
            {
                AuthenticationMethod method = new PasswordAuthenticationMethod(user, pass);
                ConnectionInfo connection = new ConnectionInfo(ip, user, method);
                SshClient client = new SshClient(connection);

                if (!client.IsConnected)
                {
                    client.Connect();


                    SshCommand response = client.RunCommand(str);
                   
                    strLog = File.ReadAllText(filePath);
                    File.WriteAllText(filePath, strLog + "\r\n" + "[×] " + "HO_Backup_Enable" + " " + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt") + "  ==> (Switch to Lan4)");
                    //txt_response.Text = response.Result;

                }
            }
            catch (Exception ex)
            {
                strLog = File.ReadAllText(filePath);
                File.WriteAllText(filePath, strLog + "\r\n" + "[-] " + ex.Message +" "+ DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt"));

                return;
            }
            // قم بتنفيذ الإجراء المطلوب هنا
        }
    }
}
