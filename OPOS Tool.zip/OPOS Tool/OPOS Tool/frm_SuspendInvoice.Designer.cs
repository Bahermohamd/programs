﻿namespace OPOS_Tool
{
    partial class frm_SuspendInvoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_Server = new System.Windows.Forms.TextBox();
            this.btn_Con = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_ClosingNumber = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_PosID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_CashierID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_NumberOfReceipt = new System.Windows.Forms.TextBox();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Delete2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Opos Server:";
            // 
            // txt_Server
            // 
            this.txt_Server.Location = new System.Drawing.Point(114, 24);
            this.txt_Server.Name = "txt_Server";
            this.txt_Server.Size = new System.Drawing.Size(185, 20);
            this.txt_Server.TabIndex = 17;
            // 
            // btn_Con
            // 
            this.btn_Con.Location = new System.Drawing.Point(307, 22);
            this.btn_Con.Name = "btn_Con";
            this.btn_Con.Size = new System.Drawing.Size(105, 23);
            this.btn_Con.TabIndex = 16;
            this.btn_Con.Text = "Connect Server";
            this.btn_Con.UseVisualStyleBackColor = true;
            this.btn_Con.Click += new System.EventHandler(this.btn_Con_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Closing Number:";
            // 
            // txt_ClosingNumber
            // 
            this.txt_ClosingNumber.Location = new System.Drawing.Point(114, 59);
            this.txt_ClosingNumber.Name = "txt_ClosingNumber";
            this.txt_ClosingNumber.Size = new System.Drawing.Size(185, 20);
            this.txt_ClosingNumber.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "POS ID:";
            // 
            // txt_PosID
            // 
            this.txt_PosID.Location = new System.Drawing.Point(114, 130);
            this.txt_PosID.Name = "txt_PosID";
            this.txt_PosID.Size = new System.Drawing.Size(185, 20);
            this.txt_PosID.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Cashier ID:";
            // 
            // txt_CashierID
            // 
            this.txt_CashierID.Location = new System.Drawing.Point(114, 95);
            this.txt_CashierID.Name = "txt_CashierID";
            this.txt_CashierID.Size = new System.Drawing.Size(185, 20);
            this.txt_CashierID.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 168);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 13);
            this.label5.TabIndex = 26;
            this.label5.Text = "Number of Receipt:";
            // 
            // txt_NumberOfReceipt
            // 
            this.txt_NumberOfReceipt.Location = new System.Drawing.Point(114, 165);
            this.txt_NumberOfReceipt.Name = "txt_NumberOfReceipt";
            this.txt_NumberOfReceipt.Size = new System.Drawing.Size(185, 20);
            this.txt_NumberOfReceipt.TabIndex = 25;
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(307, 163);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(105, 23);
            this.btn_Delete.TabIndex = 27;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Delete2
            // 
            this.btn_Delete2.Location = new System.Drawing.Point(320, 192);
            this.btn_Delete2.Name = "btn_Delete2";
            this.btn_Delete2.Size = new System.Drawing.Size(75, 23);
            this.btn_Delete2.TabIndex = 28;
            this.btn_Delete2.Text = "Delete 2";
            this.btn_Delete2.UseVisualStyleBackColor = true;
            this.btn_Delete2.Click += new System.EventHandler(this.btn_Delete2_Click);
            // 
            // frm_SuspendInvoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 233);
            this.Controls.Add(this.btn_Delete2);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_NumberOfReceipt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_PosID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_CashierID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_ClosingNumber);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Server);
            this.Controls.Add(this.btn_Con);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_SuspendInvoice";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Suspend Invoice";
            this.Load += new System.EventHandler(this.frm_SuspendInvoice_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_Server;
        private System.Windows.Forms.Button btn_Con;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_ClosingNumber;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_PosID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_CashierID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_NumberOfReceipt;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Delete2;
    }
}