﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OPOS_Tool
{
    public partial class frm_OposUserPass : Form
    {
        DBCon db = new DBCon();

        public frm_OposUserPass()
        {
            InitializeComponent();
        }

        private void btn_Con_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(txt_Server.Text))
            {
                if (txt_Server.TextLength > 9)
                {
                    try
                    {
                        //AppSetting setting = new AppSetting();

                        string db = txt_Server.Text;
                        Properties.Settings.Default.dbServer = db;
                        Properties.Settings.Default.Save();
                        //string con = @"metadata=res://*/opos.csdl|res://*/opos.ssdl|res://*/opos.msl;provider=System.Data.SqlClient;provider connection string=""data source=" + db + ";initial catalog=opos;user id=sa;password=sa;MultipleActiveResultSets=True;App=EntityFramework\"";
                        //setting.SaveConnectionString("oposEntities", con);
                        //MessageBox.Show("Saved");
                        Application.Restart();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
                else { MessageBox.Show("Please Check Server IP"); }
            }
            else { MessageBox.Show("Please Current POS Server"); }
            
        }

        private void btn_viewUser_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txt_UserID.Text))
            {
                decimal id = Convert.ToDecimal(txt_UserID.Text);

                try
                {

                    DataTable tbl = new DataTable();
                    tbl = db.readData("select user_name from users where user_id = " + id + "", "");
                    if (tbl.Rows.Count >= 1)
                    {
                        txt_UserName.Text = tbl.Rows[0][0].ToString();
                        button1.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("User Not Found");
                        txt_UserName.Clear();
                        txt_UserID.Select();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
            }
            else { MessageBox.Show("Please Write Employye Code"); }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal id = Convert.ToDecimal(txt_UserID.Text);

            try
            {
                db.exceuteData("update users set user_pwd = '3' where user_id = " + id + "", "Password has been Changed");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void frm_OposUserPass_Load(object sender, EventArgs e)
        {
            txt_Server.Text = Properties.Settings.Default.dbServer;

        }

        private void txt_Server_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
