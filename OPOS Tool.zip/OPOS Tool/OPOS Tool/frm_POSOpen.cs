﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OPOS_Tool
{
   
    public partial class frm_POSOpen : Form
    {
        DBCon db = new DBCon();
        DataTable dt = new DataTable();
        int id;

        public frm_POSOpen()
        {
            InitializeComponent();
        }

        private void btn_Con_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txt_Server.Text))
            {
                if (txt_Server.TextLength > 9)
                {
                    try
                    {
                        string db = txt_Server.Text;
                        Properties.Settings.Default.dbServer = db;
                        Properties.Settings.Default.Save();
                        //MessageBox.Show("Application Restarted");
                        Application.Restart();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
                else { MessageBox.Show("Please Check Server IP"); }
            }
            else { MessageBox.Show("Please Current POS Server"); }

            
        }

        private void frm_POSOpen_Load(object sender, EventArgs e)
        {
            txt_Server.Text = Properties.Settings.Default.dbServer;

        }

        private void btn_GetData_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txt_Server.Text))
            {
                if (txt_Server.TextLength > 9)
                {
                    try
                    {
                        dt = db.readData("select * from pos_open", "");
                        dataGridView1.DataSource = dt;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                else { MessageBox.Show("Please Check Server IP"); }
                
            }
            else { MessageBox.Show("Please Current POS Server"); }
            
            
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            DownloadFileFTP();
        }

        public void DownloadFileFTP()
        {
            try {
                id = int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                string ip = Properties.Settings.Default.dbServer;
                int length = ip.Length;
                string cutip = ip.Substring(0, length - 2);
                string ftphost = "";
                if (id == 101)
                {
                    ftphost = cutip + "11";
                }
                else if (id == 102)
                {
                    ftphost = cutip + "12";
                }
                else if (id == 103)
                {
                    ftphost = cutip + "13";
                }
                else if (id == 104)
                {
                    ftphost = cutip + "14";
                }
                else if (id == 210)
                {
                    ftphost = cutip + "69";
                }

                string ftpfilepath = @"\C$\opos\opos.ini";

                string ftpfullpath = @"\\" + ftphost + ftpfilepath;

                using (WebClient request = new WebClient())
                {
                    request.Credentials = new NetworkCredential("syssecure", "OthaiM254254*");
                    byte[] fileData = request.DownloadData(ftpfullpath);
                    using (StreamWriter writer = new StreamWriter(ftpfullpath))
                    {

                        writer.WriteLine("[DataBase]");
                        writer.WriteLine("  ProfileName = opos");
                        writer.WriteLine("  UID = sa");
                        writer.WriteLine("  PWD = sa");
                        writer.WriteLine("  \r\n");
                        writer.WriteLine("[POS]");
                        if (id == 101)
                        {
                            writer.WriteLine("  POS_ID = 101");
                        }
                        else if (id == 102)
                        {
                            writer.WriteLine("  POS_ID = 102");
                        }
                        else if (id == 103)
                        {
                            writer.WriteLine("  POS_ID = 103");
                        }
                        else if (id == 104)
                        {
                            writer.WriteLine("  POS_ID = 104");
                        }
                        else if (id == 210)
                        {
                            writer.WriteLine("  POS_ID = 210");
                        }
                        writer.WriteLine("  TS = N");
                        writer.WriteLine("  C_id = 76414");
                        writer.WriteLine("  \r\n");
                        writer.WriteLine("/*Specify P->if machine type is Pos or C->for PC KIOSK-> to run line kiosk machine");
                        writer.WriteLine("  \r\n");
                        writer.WriteLine("[Machinetype]");
                        writer.WriteLine("  type=C");
                        writer.WriteLine("  \r\n");
                        writer.WriteLine("/* Specify Printer type R=receipt printer, A=A4 size paper,this option will function if machine type is C [pc]");
                        writer.WriteLine("/* specify  Mpdel= S=Samsung , E= Epson");
                        writer.WriteLine("  \r\n");
                        writer.WriteLine("[Printer]");
                        writer.WriteLine("  prn_type=R");
                        writer.WriteLine("  Model=E");
                        writer.WriteLine("  \r\n");
                        writer.WriteLine("[closing]");
                        writer.WriteLine("  closing = Y");
                        writer.WriteLine("  \r\n");
                        writer.WriteLine("[Advertisement]");
                        writer.WriteLine("  ad_len = 62000");
                    }
                }
                id = int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                db.exceuteData("delete from pos_open where pos_id = " + id + "", "Delete POS OPEN Successfuly");
                btn_GetData_Click(null, null);

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }


        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            btn_Delete.Enabled = true;
        }
    }
}
