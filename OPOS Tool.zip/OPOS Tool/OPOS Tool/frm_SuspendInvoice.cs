﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OPOS_Tool
{
    public partial class frm_SuspendInvoice : Form
    {
        DBCon db = new DBCon();
        int s_cln, s_cashier, s_pos_id, s_num;

        public frm_SuspendInvoice()
        {
            InitializeComponent();
        }

       

        private void frm_SuspendInvoice_Load(object sender, EventArgs e)
        {
            txt_Server.Text = Properties.Settings.Default.dbServer;
        }

        private void btn_Con_Click(object sender, EventArgs e)
        {
            try
            {

                string db = txt_Server.Text;
                Properties.Settings.Default.dbServer = db;
                Properties.Settings.Default.Save();
               
                MessageBox.Show("Saved");
                Application.Restart();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {

            DataTable tbl = new DataTable();

            s_cln = int.Parse(txt_ClosingNumber.Text);
            s_cashier = int.Parse(txt_CashierID.Text);
            s_pos_id = int.Parse(txt_PosID.Text);
            s_num = int.Parse(txt_NumberOfReceipt.Text);

            try
            {

                //select* from suspend_amount where   s_cln = 1529  and s_cashier = 75106 and s_pos_id = 102  and s_num = 205-- رقم الفاتوره
                //delete suspend_amount  where s_cln = 1529  and s_cashier = 75106 and s_pos_id = 102  and s_num = 205

                //select* from suspend_retrieve where   cln = 1529  and cashier = 75106  and amount = 1005.11
                //delete suspend_retrieve  where cln = 1529  and cashier = 75106 and amount = 1005.11

                //select* from suspend_recall where    s_cln = 1529  and s_cashier = 75106 and s_pos_id = 102  and s_num = 205
                //delete suspend_recall  where s_cln = 1529  and s_cashier = 75106 and s_pos_id = 102  and s_num = 205

                //select* from suspend_open where  cln = 1529 and num = 205 and pos_id = 102
                //delete suspend_open where cln = 1529 and num = 205
                
                //------------1------------//
                //tbl = db.readData("select* from suspend_amount where   s_cln = " + s_cln + "  and s_cashier = " + s_cashier + " and s_pos_id = " + s_pos_id + "  and s_num = " + s_num + "", "");
                //if (tbl.Rows.Count >= 1)
                //{
                //    amount = int.Parse(tbl.Rows[0][0].ToString());
                //    db.exceuteData("delete suspend_amount  where s_cln = " + s_cln + "  and s_cashier = " + s_cashier + " and s_pos_id = " + s_pos_id + "  and s_num = " + s_num + "", "");
                //}
                //else
                //{
                //    MessageBox.Show("Not Found");
                //}
                //------------2------------//
                tbl.Clear();
                
                db.exceuteData("delete suspend_retrieve  where cln = " + s_cln + "  and cashier = " + s_cashier + "", "");
                
                //------------3------------//
                tbl.Clear();
                tbl = db.readData("select* from suspend_recall where    s_cln = " + s_cln + "  and s_cashier = " + s_cashier + " and s_pos_id = " + s_pos_id + "  and s_num = " + s_num + "", "");
                if (tbl.Rows.Count >= 1)
                {
                    db.exceuteData("delete suspend_recall  where s_cln = " + s_cln + "  and s_cashier = " + s_cashier + " and s_pos_id = " + s_pos_id + "  and s_num = " + s_num + "", "");
                }
                else
                {
                    MessageBox.Show("Not Found");
                    return;
                }
                //------------4------------//
                tbl.Clear();
                tbl = db.readData("select* from suspend_open where  cln = " + s_cln + " and num = " + s_num + " and pos_id = " + s_pos_id + "", "");
                if (tbl.Rows.Count >= 1)
                {
                    db.exceuteData("delete suspend_open where cln = " + s_cln + " and num = " + s_num + "", "");
                }
                else
                {
                    MessageBox.Show("Not Found");
                    return;
                }
                //-------------------------//

                MessageBox.Show("Done");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void btn_Delete2_Click(object sender, EventArgs e)
        {

            DataTable tbl = new DataTable();

            s_cln = int.Parse(txt_ClosingNumber.Text);
            s_cashier = int.Parse(txt_CashierID.Text);
            s_pos_id = int.Parse(txt_PosID.Text);
            s_num = int.Parse(txt_NumberOfReceipt.Text);

            try {
                //Step 2
                //-------------------------//
                db.exceuteData(" delete ih where stat = 'I'", "");
                //-------------------------//
                db.exceuteData("delete ih where stat = 'S'  and cln = " + s_cln + " and num = " + s_num + " and casher = " + s_cashier + "", "");
                //-------------------------//
                db.exceuteData("delete from id where cln = " + s_cln + " and num = " + s_num + " and pos_id = " + s_pos_id + "", "");
                //-------------------------//
                db.exceuteData("delete from invcs where  cln = " + s_cln + " and num = " + s_num + " and pos_id = " + s_pos_id + "", "");
                //-------------------------//
                db.exceuteData("delete from all_discounts_id where  cln = " + s_cln + " and num = " + s_num + " and pos_id = " + s_pos_id + "", "");
                //-------------------------//
                db.exceuteData("delete from ih where stat = 'S' and cln = " + s_cln + " and casher = " + s_cashier + "", "");
                //-------------------------//
                db.exceuteData("delete from id where cln = " + s_cln + " and pos_id = " + s_pos_id + " and num = " + s_num + "", "");

                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            //  select* from inv_pay_det where  cln = 1529 and num = 205 and pos_id = 102
            // --delete from scanned_invcs

            // --select id.num , *from id left join
            //--ih on id.cln = ih.cln and id.pos_id = ih.pos_id and id.num = ih.num
            //    --where ih.num is null
        }
    }
}
