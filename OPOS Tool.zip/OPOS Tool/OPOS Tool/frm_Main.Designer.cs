﻿namespace OPOS_Tool
{
    partial class frm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.oPOSPassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.posOpenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suspendInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oPOSPassToolStripMenuItem,
            this.posOpenToolStripMenuItem,
            this.suspendInvoiceToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(821, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // oPOSPassToolStripMenuItem
            // 
            this.oPOSPassToolStripMenuItem.Name = "oPOSPassToolStripMenuItem";
            this.oPOSPassToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.oPOSPassToolStripMenuItem.Text = "OPOS Pass";
            this.oPOSPassToolStripMenuItem.Click += new System.EventHandler(this.oPOSPassToolStripMenuItem_Click);
            // 
            // posOpenToolStripMenuItem
            // 
            this.posOpenToolStripMenuItem.Name = "posOpenToolStripMenuItem";
            this.posOpenToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.posOpenToolStripMenuItem.Text = "Pos Open";
            this.posOpenToolStripMenuItem.Click += new System.EventHandler(this.posOpenToolStripMenuItem_Click);
            // 
            // suspendInvoiceToolStripMenuItem
            // 
            this.suspendInvoiceToolStripMenuItem.Enabled = false;
            this.suspendInvoiceToolStripMenuItem.Name = "suspendInvoiceToolStripMenuItem";
            this.suspendInvoiceToolStripMenuItem.Size = new System.Drawing.Size(105, 20);
            this.suspendInvoiceToolStripMenuItem.Text = "Suspend Invoice";
            this.suspendInvoiceToolStripMenuItem.Click += new System.EventHandler(this.suspendInvoiceToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 472);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(821, 497);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frm_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ITOPS Tool";
            this.Load += new System.EventHandler(this.frm_Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem oPOSPassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suspendInvoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem posOpenToolStripMenuItem;
        private System.Windows.Forms.Label label1;
    }
}