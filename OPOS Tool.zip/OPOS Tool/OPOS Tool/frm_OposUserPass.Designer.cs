﻿namespace OPOS_Tool
{
    partial class frm_OposUserPass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txt_UserName = new System.Windows.Forms.TextBox();
            this.txt_UserID = new System.Windows.Forms.TextBox();
            this.btn_viewUser = new System.Windows.Forms.Button();
            this.txt_Server = new System.Windows.Forms.TextBox();
            this.btn_Con = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "User Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "User ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Opos Server:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(286, 97);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(124, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Change Password";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt_UserName
            // 
            this.txt_UserName.Location = new System.Drawing.Point(93, 99);
            this.txt_UserName.Name = "txt_UserName";
            this.txt_UserName.ReadOnly = true;
            this.txt_UserName.Size = new System.Drawing.Size(185, 20);
            this.txt_UserName.TabIndex = 13;
            // 
            // txt_UserID
            // 
            this.txt_UserID.Location = new System.Drawing.Point(93, 62);
            this.txt_UserID.MaxLength = 6;
            this.txt_UserID.Name = "txt_UserID";
            this.txt_UserID.Size = new System.Drawing.Size(185, 20);
            this.txt_UserID.TabIndex = 12;
            // 
            // btn_viewUser
            // 
            this.btn_viewUser.Location = new System.Drawing.Point(286, 60);
            this.btn_viewUser.Name = "btn_viewUser";
            this.btn_viewUser.Size = new System.Drawing.Size(75, 23);
            this.btn_viewUser.TabIndex = 11;
            this.btn_viewUser.Text = "Show User";
            this.btn_viewUser.UseVisualStyleBackColor = true;
            this.btn_viewUser.Click += new System.EventHandler(this.btn_viewUser_Click);
            // 
            // txt_Server
            // 
            this.txt_Server.Location = new System.Drawing.Point(93, 25);
            this.txt_Server.MaxLength = 11;
            this.txt_Server.Name = "txt_Server";
            this.txt_Server.Size = new System.Drawing.Size(185, 20);
            this.txt_Server.TabIndex = 10;
            this.txt_Server.TextChanged += new System.EventHandler(this.txt_Server_TextChanged);
            // 
            // btn_Con
            // 
            this.btn_Con.Location = new System.Drawing.Point(286, 23);
            this.btn_Con.Name = "btn_Con";
            this.btn_Con.Size = new System.Drawing.Size(105, 23);
            this.btn_Con.TabIndex = 9;
            this.btn_Con.Text = "Connect Server";
            this.btn_Con.UseVisualStyleBackColor = true;
            this.btn_Con.Click += new System.EventHandler(this.btn_Con_Click);
            // 
            // frm_OposUserPass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 145);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt_UserName);
            this.Controls.Add(this.txt_UserID);
            this.Controls.Add(this.btn_viewUser);
            this.Controls.Add(this.txt_Server);
            this.Controls.Add(this.btn_Con);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_OposUserPass";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OPOS Password";
            this.Load += new System.EventHandler(this.frm_OposUserPass_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_UserName;
        private System.Windows.Forms.TextBox txt_UserID;
        private System.Windows.Forms.Button btn_viewUser;
        private System.Windows.Forms.TextBox txt_Server;
        private System.Windows.Forms.Button btn_Con;
    }
}