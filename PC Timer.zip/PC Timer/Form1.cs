﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using WMPLib;
using System.IO;

namespace PC_Timer
{
    public partial class Form1 : Form
    {
        string status = "Timer Close";
        TimeSpan Action_Time; //متغير يوضع فيه الوقت
        int Hour,Minute; //متغير للساعات وللدقائق
        int num;
        [DllImport("PowrProf.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern bool SetSuspendState(bool hiberate, bool forceCritical, bool disableWakeEvent); 

        public Form1()
        {
            InitializeComponent();
            toolStripStatusLabel1.Text = "Local Time: " + DateTime.Now.ToString(@"hh:mm tt");
            timer2.Start(); //فتح تايمر الساعة المحلية
        }

        private void btn_SetTimer_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            if (nud_Hour.Value == 0 && nud_Minute.Value == 0)
            {
                if (comboBox1.Text == "")
                {
                    MessageBox.Show("Pleas Check Action Mode");
                }
                else if(comboBox1.Text=="Alarm")
                {
                    MessageBox.Show("Pleas Set Action Time");
                }
                else if (MessageBox.Show("Are you sure you want to " + comboBox1.Text + " " + Environment.MachineName + " PC", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                {
                    if (comboBox1.Text == "Shutdown")
                    {
                        Process.Start("shutdown", "/s /t 0");
                    }
                    else if (comboBox1.Text == "Restart")
                    {
                        Process.Start("shutdown", "/r /t 0"); 
                    }
                    else if (comboBox1.Text == "Sleep")
                    {
                        SetSuspendState(false, true, true);
                    }
                    else if (comboBox1.Text == "Lock")
                    {
                        Process.Start(@"C:\WINDOWS\system32\rundll32.exe", "user32.dll,LockWorkStation");
                    }
                    else if (comboBox1.Text == "Hibernate")
                    {
                        Process.Start("shutdown", "/h /f");
                    }
                }
                
            }
            else
            {
                Hour = int.Parse(nud_Hour.Text); //إعطاء قيمة لمتغير الساعات
                Minute = int.Parse(nud_Minute.Text);//إعطاء قيمة لمتغير الدقائق
                Action_Time = new TimeSpan(Hour, Minute, 00);//إعطاء متغير الوقت قيمه
                progressBar1.Maximum = (Hour * 60 * 60) + (Minute * 60);
                timer1.Start();
                btn_SetTimer.Enabled = false;
                btn_Cancel.Enabled = true;
                status = "Timer Open";
            }//تشغيل تايمر البرنامج
        }

        void reset()
        {
            btn_SetTimer.Enabled = true;
            btn_Cancel.Enabled = false;
            progressBar1.Value = 0;
            lbl_Percent.Text = "0%";
            nud_Hour.Value = 0;
            nud_Minute.Value = 0;
            comboBox1.SelectedIndex = -1;
            if(notifyIcon1.Visible==true)
            {
                this.WindowState = FormWindowState.Normal;
                notifyIcon1.Visible = false;
                this.ShowInTaskbar = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            num += 1;
            lbl_Percent.Text = (100 * num / progressBar1.Maximum).ToString() + "%";
            progressBar1.Value += 1;
            Action_Time-=new TimeSpan(00,00,01);
            notifyIcon1.Text = this.Text + "\r\n" + "Status : " + status + "\r\n" + "Progress : " + lbl_Percent.Text;
            if (Action_Time == new TimeSpan(00, 00, 00))
            {
                timer1.Stop();
                if (comboBox1.Text == "Alarm")
                {
                    reset();
                    WMPLib.WindowsMediaPlayer player = new WindowsMediaPlayer();
                    player.URL = "Sound.mp3";
                    player.controls.play();
                    MessageBox.Show("Close Alarm");
                    player.controls.stop();
                }
                else if (comboBox1.Text == "Shutdown")
                {
                    reset();
                    Process.Start("shutdown", "/s /t 0");
                }
                else if (comboBox1.Text == "Restart")
                {
                    reset();
                    Process.Start("shutdown", "/r /t 0");
                }
                else if (comboBox1.Text == "Sleep")
                {
                    reset();
                    SetSuspendState(false, true, true);
                }
                else if (comboBox1.Text == "Lock")
                {
                    reset();
                    Process.Start(@"C:\WINDOWS\system32\rundll32.exe", "user32.dll,LockWorkStation");
                }
                else if (comboBox1.Text == "Hibernate")
                {
                    reset();
                    Process.Start("shutdown", "/h /f");
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Local Time: " + DateTime.Now.ToString(@"hh:mm t");
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to cancel the Timer " + comboBox1.Text, "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                timer1.Stop();
                reset();
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.WindowState = FormWindowState.Normal;
                notifyIcon1.Visible = false;
                this.ShowInTaskbar = true;
            }
        }

        private void changeSoundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog soundfile = new OpenFileDialog();
            soundfile.Filter = "ملفات الصوت |*.mp3;";
            if (soundfile.ShowDialog()==DialogResult.OK)
            {
                try
                {
                    string sourcePath = soundfile.FileName;
                    string newfile = "Sound.mp3";
                    File.Copy(soundfile.FileName, newfile, true);
                }
                catch { return; }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            notifyIcon1.Visible = true;
            notifyIcon1.Icon = this.Icon;
            this.ShowInTaskbar = false;
            if (status == "Timer Open")
            {
                notifyIcon1.Text = this.Text + "\r\n" + "Status : " + status + "\r\n" + "Progress : " + lbl_Percent.Text;
            }
            else
            {
                notifyIcon1.Text = this.Text + "\r\n" + "Status : " + status;
            }
        }
       
    }
}
